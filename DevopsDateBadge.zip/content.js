// chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
//     $("head").prepend(
//       `<style>
//          .slide-image {
//             height: auto;
//             width: 100vw;
//           }
//         </style> `
//     );
//     $("body").prepend(
//       `<img  src="${request.url}" id="${request.imageDivId}" 
//              class="slide-image" /> `
//     );
//     $(`#${request.imageDivId}`).click(function() {
//       $(`#${request.imageDivId}`).remove(`#${request.imageDivId}`);
//     });
//     sendResponse({ fromcontent: "This message is from content.js" });
//   });

function processdates () {
   // Get all the divs on the page
   var committedDateDivs = document.querySelectorAll('div.additional-field[field*="CommittedDate"] .field-inner-element');
   console.log(committedDateDivs.length);

   var today = new Date();

   // Loop though all the divs
   for(var i = 0; i < committedDateDivs.length; i++){
      var committedDate = committedDateDivs[i];
   
      if (committedDate.innerText) {

         if (committedDate.nextSibling && committedDate.nextSibling.className === "sensei-date-badge") {
            committedDate.parentNode.removeChild(committedDate.nextSibling);
         }

         var daysOldNode = document.createElement("div");
         daysOldNode.className = "sensei-date-badge";
         daysOldNode.title = "Days Old";
         daysOldNode.style.position = "absolute";
         daysOldNode.style.right = "5px";
         daysOldNode.style.width = "35px";
         daysOldNode.style.marginTop = "-22px";

         var parts = committedDate.innerText.split("/");
         var date = new Date(parseInt(parts[2], 10), parseInt(parts[1], 10) - 1, parseInt(parts[0], 10));     
         var differenceInTime = date.getTime() - today.getTime();
         var differenceinDays = 0 - (differenceInTime / (1000 * 3600 * 24));   


         var icon = document.createElement("i");
         icon.className = "bowtie-icon bowtie-status-waiting";
         icon.style.color = "green";
         icon.style.marginRight = "2px"

         if (differenceinDays > 20) {
            icon.style.color = "red";
         } else if (differenceinDays > 10) {
            icon.style.color = "orange";
         }

         daysOldNode.append(icon);
         daysOldNode.append(differenceinDays.toFixed());

         committedDate.after(daysOldNode);
      }
   }
}

setInterval(() => {
   processdates();
}, 5000);